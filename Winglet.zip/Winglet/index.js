// index.js — full version without Tour Type toggle, still with Dark Mode
document.addEventListener("DOMContentLoaded", () => {
  // ---------- Dark Mode Toggle ----------
  const darkModeBtn = document.querySelector(".dark-mode");
  darkModeBtn?.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode-variables");
    darkModeBtn
      .querySelectorAll("span")
      .forEach((s) => s.classList.toggle("active"));
  });

  // ---------- Helpers ----------
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => Array.from(root.querySelectorAll(s));
  const val = (el) => (el ? el.value.trim() : "");
  const toMoney = (n) => (isFinite(n) ? Number(n).toFixed(2) : "0.00");

  const hasOption = (options, v) =>
    Array.from(options).some(
      (o) => (o.value || o.textContent || "").toLowerCase() === v.toLowerCase()
    );

  const ensureAfterContainer = (afterEl, id, className = "tag-list") => {
    let box = document.getElementById(id);
    if (!box) {
      box = document.createElement("div");
      box.id = id;
      box.className = className;
      afterEl.insertAdjacentElement("afterend", box);
    }
    return box;
  };

  const makeTag = (container, label, onRemove) => {
    const tag = document.createElement("span");
    tag.className = "tag";
    const t = document.createElement("span");
    t.className = "tag-text";
    t.textContent = label;
    const x = document.createElement("button");
    x.type = "button";
    x.className = "tag-remove";
    x.textContent = "×";
    x.addEventListener("click", () => {
      try {
        onRemove?.();
      } finally {
        tag.remove();
      }
    });
    tag.append(t, x);
    container.appendChild(tag);
  };

  // ---------- Customer toggle logic ----------
  const custInput = $("#customer-name");
  const customersDL = $("#customers");
  const newCustFields = $(".new-customer-fields");
  if (custInput && customersDL && newCustFields) {
    const toggleNew = () => {
      newCustFields.hidden = hasOption(customersDL.options, custInput.value);
    };
    custInput.addEventListener("input", toggleNew);
    toggleNew();
  }

  // ---------- Country → City data & Destinations logic ----------
  const CITY_MAP = {
    georgia: ["Tbilisi", "Batumi", "Kutaisi"],
    france: ["Paris", "Lyon", "Nice", "Marseille"],
    italy: ["Rome", "Milan", "Florence", "Venice"],
    spain: ["Madrid", "Barcelona", "Valencia", "Seville"],
    turkey: ["Istanbul", "Antalya", "Ankara", "Izmir"],
  };

  const populateCities = (countrySel, citySel) => {
    if (!countrySel || !citySel) return;
    while (citySel.options.length) citySel.remove(0);
    citySel.add(new Option("-- City --", ""));
    (CITY_MAP[(countrySel.value || "").toLowerCase()] || []).forEach((city) => {
      citySel.add(new Option(city, city));
    });
    citySel.selectedIndex = 0;
  };

  const ensureDestSummary = (group) => {
    let sum = group.querySelector(".dest-summary");
    if (!sum) {
      sum = document.createElement("div");
      sum.className = "dest-summary";
      group.appendChild(sum);
    }
    return sum;
  };

  const updateDestSummary = (group) => {
    const countrySel = group.querySelector(
      'select[name="destinationCountry[]"]'
    );
    const citySel = group.querySelector('select[name="destinationCity[]"]');
    const sum = ensureDestSummary(group);
    const c = countrySel?.selectedOptions[0]?.text || "";
    const city = citySel?.selectedOptions[0]?.text || "";
    sum.textContent =
      c || city ? `Selected: ${c || "—"}${city ? " – " + city : ""}` : "";
  };

  const destFieldset = $(".destination-fields");
  if (destFieldset) {
    const addBtn = $("#add-destination", destFieldset);
    const baseGroup = $(".destination-group", destFieldset);

    const addRemoveBtn = (group) => {
      if (!group.querySelector(".remove-destination")) {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "btn-remove remove-destination";
        b.textContent = "Remove Destination";
        group.appendChild(b);
      }
      ensureDestSummary(group);
    };

    if (baseGroup) {
      addRemoveBtn(baseGroup);
      populateCities(
        baseGroup.querySelector('select[name="destinationCountry[]"]'),
        baseGroup.querySelector('select[name="destinationCity[]"]')
      );
      updateDestSummary(baseGroup);
    }

    addBtn?.addEventListener("click", () => {
      const clone = baseGroup.cloneNode(true);
      $$("input, select", clone).forEach((el) => {
        if (el.tagName === "SELECT") el.selectedIndex = 0;
        else el.value = "";
      });
      addRemoveBtn(clone);
      const ctry = clone.querySelector('select[name="destinationCountry[]"]');
      const city = clone.querySelector('select[name="destinationCity[]"]');
      populateCities(ctry, city);
      updateDestSummary(clone);
      addBtn.before(clone);
    });

    destFieldset.addEventListener("click", (e) => {
      const btn = e.target.closest(".remove-destination");
      if (!btn) return;
      const group = btn.closest(".destination-group");
      if (!group) return;
      const groups = $$(".destination-group", destFieldset);
      if (groups.length > 1) group.remove();
    });

    destFieldset.addEventListener("change", (e) => {
      const group = e.target.closest(".destination-group");
      if (!group) return;
      if (e.target.matches('select[name="destinationCountry[]"]')) {
        populateCities(
          e.target,
          group.querySelector('select[name="destinationCity[]"]')
        );
        updateDestSummary(group);
      }
      if (e.target.matches('select[name="destinationCity[]"]'))
        updateDestSummary(group);
    });
  }

  // ---------- Travelers logic ----------
  const travNum = $("#num-travelers");
  const travFieldset = $(".additional-travelers");
  const addTravelerBtn = $("#add-traveler");
  const travList = $("#additional-list");

  if (travNum && travFieldset) {
    const sync = () => {
      travFieldset.hidden = Number(travNum.value || 0) <= 1;
    };
    travNum.addEventListener("change", sync);
    sync();
  }

  addTravelerBtn?.addEventListener("click", () => {
    const row = document.createElement("div");
    row.className = "traveler-item";
    const input = document.createElement("input");
    input.type = "text";
    input.name = "additionalTravelerNames[]";
    input.placeholder = "Traveler Name";
    const rem = document.createElement("button");
    rem.type = "button";
    rem.className = "btn-remove";
    rem.textContent = "Remove";
    rem.addEventListener("click", () => row.remove());
    row.append(input, rem);
    travList.appendChild(row);
  });

  const participantInput = document.getElementById("participant-input");
  const addParticipantBtn = document.getElementById("add-participant");
  const participantList = document.getElementById("participant-list");

  if (participantInput && addParticipantBtn && participantList) {
    addParticipantBtn.addEventListener("click", () => {
      const fullName = participantInput.value.trim();
      if (!fullName) {
        alert("Please enter the participant’s full name.");
        return;
      }

      const div = document.createElement("div");
      div.className = "participant-item";

      const span = document.createElement("span");
      span.textContent = fullName;

      const removeBtn = document.createElement("button");
      removeBtn.type = "button";
      removeBtn.className = "btn-remove";
      removeBtn.textContent = "Remove";
      removeBtn.addEventListener("click", () => div.remove());

      div.append(span, removeBtn);
      participantList.appendChild(div);

      participantInput.value = "";
    });
  }

  // ---------- Additional Services logic ----------
  const servicesSelect = $("#additional-services");
  const newServiceInput = $("#new-service");
  const addServiceBtn = $("#add-service");

  if (servicesSelect && newServiceInput && addServiceBtn) {
    const tagBox = ensureAfterContainer(servicesSelect, "service-tags");
    const addService = (name) => {
      if (!name) return;
      if (hasOption(servicesSelect.options, name)) {
        newServiceInput.value = "";
        return;
      }
      servicesSelect.add(new Option(name, name));
      makeTag(tagBox, name, () => {
        const idx = Array.from(servicesSelect.options).findIndex(
          (o) => o.value === name
        );
        if (idx > -1) servicesSelect.remove(idx);
      });
      newServiceInput.value = "";
    };
    addServiceBtn.addEventListener("click", () =>
      addService(val(newServiceInput))
    );
    newServiceInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        addService(val(newServiceInput));
      }
    });
  }

  // ---------- Supplier chips logic ----------
  const suppliersDL = $("#suppliers");
  const addSupplierBtn = $("#add-supplier");
  const newSupplierInput = $("#new-supplier");

  if (suppliersDL && addSupplierBtn && newSupplierInput) {
    const tagBox = ensureAfterContainer(suppliersDL, "supplier-tags");
    const addSupplier = (name) => {
      if (!name) return;
      if (hasOption(suppliersDL.options, name)) {
        newSupplierInput.value = "";
        return;
      }
      suppliersDL.appendChild(
        Object.assign(document.createElement("option"), { value: name })
      );
      makeTag(tagBox, name, () => {
        const found = Array.from(suppliersDL.options).find(
          (o) => o.value === name
        );
        if (found) found.remove();
      });
      newSupplierInput.value = "";
    };
    addSupplierBtn.addEventListener("click", () =>
      addSupplier(val(newSupplierInput))
    );
    newSupplierInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        addSupplier(val(newSupplierInput));
      }
    });
  }

  // ---------- Order source chips logic ----------
  const orderSourceInput = $("#order-source");
  const sourcesDL = $("#sources");
  const addSourceBtn = $("#add-source");
  const newSourceInput = $("#new-source");

  if (orderSourceInput && sourcesDL && addSourceBtn && newSourceInput) {
    const tagBox = ensureAfterContainer(orderSourceInput, "source-tags");
    const addSource = (name) => {
      if (!name) return;
      if (hasOption(sourcesDL.options, name)) {
        newSourceInput.value = "";
        return;
      }
      sourcesDL.appendChild(
        Object.assign(document.createElement("option"), { value: name })
      );
      makeTag(tagBox, name, () => {
        const found = Array.from(sourcesDL.options).find(
          (o) => o.value === name
        );
        if (found) found.remove();
      });
      newSourceInput.value = "";
    };
    addSourceBtn.addEventListener("click", () =>
      addSource(val(newSourceInput))
    );
    newSourceInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        addSource(val(newSourceInput));
      }
    });
  }

  // ---------- Component currency toggle ----------
  const compCurr = $("#component-currency");
  const rateGroup = $(".foreign-rate-group");
  if (compCurr && rateGroup) {
    const syncRate = () => {
      rateGroup.hidden = compCurr.value === "GEL";
    };
    compCurr.addEventListener("change", syncRate);
    syncRate();
  }

  // ---------- Classic Payments logic ----------
  const salePriceInput = $("#sale-price");
  const bankSel = $("#payment-bank");
  const amountInput = $("#payment-amount");
  const addPaymentBtn = $("#add-payment");
  const paymentsList = $("#payments-list");

  if (addPaymentBtn && paymentsList && salePriceInput) {
    addPaymentBtn.addEventListener("click", () => {
      const amt = parseFloat(val(amountInput));
      const bank = val(bankSel);
      if (!bank || !amt) return;
      const div = document.createElement("div");
      div.textContent = `${bank}: ${toMoney(amt)}`;
      paymentsList.appendChild(div);
      amountInput.value = "";
      const total = Array.from(paymentsList.children).reduce((s, c) => {
        return s + parseFloat(c.textContent.split(":")[1] || 0);
      }, 0);
      $("#total-paid").textContent = toMoney(total);
      const remaining = parseFloat(val(salePriceInput)) - total;
      $("#remaining").textContent = toMoney(remaining);
    });
  }
});
// ===== Company Expenses Logic =====
let expenses = [];
const exchangeRates = { USD: 2.7, EUR: 3.0, GEL: 1 }; // example fixed rates

const expenseReason = document.getElementById("expense-reason");
const expenseAmount = document.getElementById("expense-amount");
const expenseCurrency = document.getElementById("expense-currency");
const addExpenseBtn = document.getElementById("add-expense");
const expensesList = document.getElementById("expenses-list");
const totalExpensesEl = document.getElementById("total-expenses");
const expenseStatus = document.getElementById("expense-status");

addExpenseBtn.addEventListener("click", () => {
  const reason = expenseReason.value.trim();
  const amount = parseFloat(expenseAmount.value) || 0;
  const currency = expenseCurrency.value;

  if (!reason || amount <= 0)
    return alert("Please enter valid expense details.");

  const gelAmount = amount * exchangeRates[currency];
  expenses.push({ reason, amount, currency, gelAmount });
  renderExpenses();

  expenseReason.value = "";
  expenseAmount.value = "";
  expenseCurrency.value = "GEL";
});

function renderExpenses() {
  expensesList.innerHTML = "";
  let total = 0;

  expenses.forEach((exp, i) => {
    total += exp.gelAmount;
    const tag = document.createElement("div");
    tag.className = "tag";
    tag.innerHTML = `${exp.reason}: ${exp.amount} ${
      exp.currency
    } (${exp.gelAmount.toFixed(
      2
    )} GEL) <button onclick="removeExpense(${i})">x</button>`;
    expensesList.appendChild(tag);
  });

  totalExpensesEl.textContent = total.toFixed(2);
  updateExpenseStatus(total);
}

window.removeExpense = function (index) {
  expenses.splice(index, 1);
  renderExpenses();
};

function updateExpenseStatus(totalExpenses) {
  const gross = parseFloat(document.getElementById("sale-price").value) || 0;
  const totalPaid =
    parseFloat(document.getElementById("total-paid").textContent) || 0;

  if (totalPaid >= gross && totalExpenses >= gross) {
    expenseStatus.textContent = "Fully Covered";
    expenseStatus.className = "status-label status-green";
  } else if (totalPaid > 0 || totalExpenses > 0) {
    expenseStatus.textContent = "Partially Covered";
    expenseStatus.className = "status-label status-orange";
  } else {
    expenseStatus.textContent = "Unpaid";
    expenseStatus.className = "status-label status-red";
  }
}
